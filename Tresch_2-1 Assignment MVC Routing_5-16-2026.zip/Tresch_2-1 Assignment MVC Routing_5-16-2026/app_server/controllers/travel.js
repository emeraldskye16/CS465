/* GET travel view */
const travel = (req, res) =>{
    res.render('travel', {title: 'Travlr'});
};

module.exports = {
    travel
};